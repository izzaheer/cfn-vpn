import json
import time
import xml.etree.ElementTree as ET
import os
import boto3
def lambda_handler(event, context):
  parameters = event['ResourceProperties']
  csr_ip = parameters['CSRIP']
  vpn_id = parameters['VPNID']
  region = parameters['Region']
  private_ip = parameters['PrivateIP']
  bucket = parameters['Bucket']
  
  vpn = boto3.client('ec2',region_name=region)
  vpn_config = vpn.describe_vpn_connections(VpnConnectionIds=[vpn_id])
  tunnel_options = vpn_config['VpnConnections'][0]['CustomerGatewayConfiguration']
  root = ET.fromstring(tunnel_options)
  csr_internal_ip = private_ip
  vpn_tunnel_ip_1 = vpn_config['VpnConnections'][0]['VgwTelemetry'][0]['OutsideIpAddress']
  vpn_tunnel_ip_2 = vpn_config['VpnConnections'][0]['VgwTelemetry'][0]['OutsideIpAddress']
  pre_shared_key_1 = root[4][2][5].text
  pre_shared_key_2 = root[5][2][5].text
  cgw_tunnel_1_inside_ip = root[4][0][1][0].text
  vgw_tunnel_1_inside_ip = root[4][1][1][0].text
  cgw_tunnel_2_inside_ip = root[5][0][1][0].text
  vgw_tunnel_2_inside_ip = root[5][1][1][0].text
  script = "config t \n\
crypto isakmp policy 200\n\
  encryption aes 128\n\
  authentication pre-share\n\
  group 2\n\
  lifetime 28800\n\
  hash sha\n\
exit\n\
\n\
crypto keyring keyring-" + vpn_id +"-0\n\
  local-address  " +  csr_internal_ip + "\n\
  pre-shared-key address  " + vpn_tunnel_ip_1 + " key " + pre_shared_key_1 + "\n\
exit\n\
\n\
crypto isakmp profile isakmp-" + vpn_id + "-0\n\
  local-address  " + csr_internal_ip + "\n\
  match identity address  " + vpn_tunnel_ip_1 + "\n\
  keyring keyring-" + vpn_id + "-0\n\
exit\n\
\n\
crypto ipsec transform-set ipsec-prop-" + vpn_id + "-0 esp-aes 128 esp-sha-hmac\n\
  mode tunnel\n\
exit\n\
\n\
crypto ipsec profile ipsec-" + vpn_id + "-0\n\
  set pfs group2\n\
  set security-association lifetime seconds 3600\n\
  set transform-set ipsec-prop-" + vpn_id + "-0\n\
exit\n\
\n\
crypto ipsec df-bit clear\n\
\n\
crypto isakmp keepalive 10 10 on-demand\n\
\n\
crypto ipsec security-association replay window-size 128\n\
\n\
crypto ipsec fragmentation before-encryption\n\
\n\
\n\
interface Tunnel1\n\
  ip address  " + cgw_tunnel_1_inside_ip + " 255.255.255.252\n\
  ip virtual-reassembly\n\
  tunnel source  " + csr_internal_ip + "\n\
  tunnel destination  " + vpn_tunnel_ip_1 + "\n\
  tunnel mode ipsec ipv4\n\
  tunnel protection ipsec profile ipsec-" + vpn_id + "-0\n\
  ip tcp adjust-mss 1379\n\
  no shutdown\n\
exit\n\
\n\
ip sla 100\n\
   icmp-echo  " + vgw_tunnel_1_inside_ip + " source-interface Tunnel1\n\
   timeout 5000\n\
   frequency 5\n\
exit\n\
ip sla schedule 100  life forever start-time now\n\
track 100 ip sla 100 reachability\n\
crypto isakmp policy 201\n\
  encryption aes 128\n\
  authentication pre-share\n\
  group 2\n\
  lifetime 28800\n\
  hash sha\n\
exit\n\
\n\
crypto keyring keyring-" + vpn_id +"-1\n\
  local-address " + csr_internal_ip +"\n\
  pre-shared-key address  " + vpn_tunnel_ip_2 + " key " + pre_shared_key_2 +"\n\
exit\n\
\n\
crypto isakmp profile isakmp-" + vpn_id +"-1\n\
  local-address " + csr_internal_ip +"\n\
  match identity address  " + vpn_tunnel_ip_2 + "\n\
  keyring keyring-" + vpn_id +"-1\n\
exit\n\
\n\
crypto ipsec transform-set ipsec-prop-" + vpn_id +"-1 esp-aes 128 esp-sha-hmac\n\
  mode tunnel\n\
exit\n\
\n\
crypto ipsec profile ipsec-" + vpn_id + "-1\n\
  set pfs group2\n\
  set security-association lifetime seconds 3600\n\
  set transform-set ipsec-prop-" + vpn_id + "-1\n\
exit\n\
\n\
crypto ipsec df-bit clear\n\
\n\
crypto isakmp keepalive 10 10 on-demand\n\
\n\
crypto ipsec security-association replay window-size 128\n\
\n\
crypto ipsec fragmentation before-encryption\n\
\n\
\n\
interface Tunnel2\n\
  ip address  " + cgw_tunnel_2_inside_ip + "255.255.255.252\n\
  ip virtual-reassembly\n\
  tunnel source  " + csr_internal_ip +"\n\
  tunnel destination  " + vpn_tunnel_ip_2 +"\n\
  tunnel mode ipsec ipv4\n\
  tunnel protection ipsec profile ipsec-" + vpn_id +"-1\n\
  ip tcp adjust-mss 1379\n\
  no shutdown\n\
exit\n\
\n\
ip sla 200\n\
   icmp-echo  " + vgw_tunnel_2_inside_ip + "source-interface Tunnel2\n\
   timeout 5000\n\
   frequency 5\n\
exit\n\
ip sla schedule 200  life forever start-time now\n\
track 200 ip sla 200 reachability\n\
exit \n\
"
  #print script
  s3 = boto3.client('s3')
  response = s3.put_object(Bucket=bucket, Key='VPN/CSR_config', Body=script)
  responseData = {'SUCCESS': 'Config Uploaded'}
  responseStatus = 'SUCCESS'
  send(event, context, responseStatus, responseData)
def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
              responseUrl = event['ResponseURL']
              print(responseUrl)
              responseBody = {'Status': responseStatus,
                              'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
                              'PhysicalResourceId': physicalResourceId or context.log_stream_name,
                              'StackId': event['StackId'],
                              'RequestId': event['RequestId'],
                              'LogicalResourceId': event['LogicalResourceId'],
                              'Data': responseData}
              json_responseBody = json.dumps(responseBody)
              print("Response body:\n" + json_responseBody)
              headers = {
                  'content-type' : '',
                  'content-length' : str(len(json_responseBody))
              }
              try:
                  response = requests.put(responseUrl,
                                          data=json_responseBody,
                                          headers=headers)
                  print("Status code: " + response.reason)
              except Exception as e:
                  print("send(..) failed executing requests.put(..): " + str(e))     