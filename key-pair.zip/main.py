import json
from cryptography.hazmat.primitives import serialization as crypto_serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend as crypto_default_backend
import boto3
import requests

def lambda_handler(event, context):
    parameters = event['ResourceProperties']
    key_pair_name = parameters['KeyPairName']
    region = parameters['Region']
    responseData={}
    try:
        if event['RequestType'] == 'Create':
            key = rsa.generate_private_key(
            backend=crypto_default_backend(),
            public_exponent=65537,
            key_size=2048)
            private_key = key.private_bytes(
            crypto_serialization.Encoding.PEM,
            crypto_serialization.PrivateFormat.PKCS8,
            crypto_serialization.NoEncryption())
            public_key = key.public_key().public_bytes(
            crypto_serialization.Encoding.OpenSSH,
            crypto_serialization.PublicFormat.OpenSSH)
            responseData={}
            ec2 = boto3.resource('ec2')
            response = ec2.import_key_pair(KeyName=key_pair_name, PublicKeyMaterial=public_key) 
            s3 = boto3.client('s3')
            response = s3.list_buckets()
            for bucket in response['Buckets']:
                bucketName = bucket['Name']
                if "cf-template" in bucketName:
                    if region in bucketName:
                        cf_bucket = bucket['Name']
                        print bucket['Name']
            s3_key="VPN/" + key_pair_name + ".pem"
            response = s3.put_object(Bucket=cf_bucket, Key=s3_key, Body=private_key)
            responseStatus = 'SUCCESS'
            responseData = { 'Success' : 'Key Pair \"" + key_pair_name + "\" has been created and private Key has been uploaded to \"s3://" + cf_bucket + "/" + s3_key + "\"' }

        elif event['RequestType'] == 'Update':
            responseStatus = 'SUCCESS'
            responseData = { 'Success' : 'No Update implementation for this Function'}
        if event['RequestType'] == 'Delete':
            ec2 = boto3.resource('ec2')
            s3 = boto3.client('s3')
            response = s3.list_buckets()
            for bucket in response['Buckets']:
                bucketName = bucket['Name']
                if "cf-template" in bucketName:
                    if region in bucketName:
                        cf_bucket = bucket['Name']
                        print bucket['Name']
            s3_key="VPN/" + key_pair_name + ".pem"
            key_pair = ec2.KeyPair(key_pair_name)
            response_ec2 = key_pair.delete()
            response_s3 = s3.delete_object(Bucket=cf_bucket, Key=s3_key)
            responseStatus = 'SUCCESS'
            responseData = { 'Success' : 'Key Pair \"" + key_pair_name + "\" has been deleted and private Key has been removed from \"s3://" + cf_bucket + "/" + s3_key + "\"' }
    except Exception as e:
        print('Failed to process:', e)
        responseStatus = 'FAILED'
        responseData = {'Failure': 'Something bad happened.'}
    send(event, context, responseStatus, responseData)
def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']
    print(responseUrl)
    responseBody = {'Status': responseStatus,
                    'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
                    'PhysicalResourceId': physicalResourceId or context.log_stream_name,
                    'StackId': event['StackId'],
                    'RequestId': event['RequestId'],
                    'LogicalResourceId': event['LogicalResourceId'],
                    'Data': responseData}
    json_responseBody = json.dumps(responseBody)
    print("Response body:\n" + json_responseBody)
    headers = {
        'content-type' : '',
        'content-length' : str(len(json_responseBody))
    }
    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))
